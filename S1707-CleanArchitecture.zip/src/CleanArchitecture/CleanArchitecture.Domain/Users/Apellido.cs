namespace CleanArchitecture.Domain.Users;

public record Apellido(string Value);