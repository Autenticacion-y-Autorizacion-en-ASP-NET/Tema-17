using MediatR;

namespace CleanArchitecture.Domain.Abstractions;

public interface IDomainEvent : INotification
{
    
}