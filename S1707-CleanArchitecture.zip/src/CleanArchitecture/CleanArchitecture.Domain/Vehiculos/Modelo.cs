using System.ComponentModel.DataAnnotations.Schema;

namespace CleanArchitecture.Domain.Vehiculos;

public record Modelo(string Value);
